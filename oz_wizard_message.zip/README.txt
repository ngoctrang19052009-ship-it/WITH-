OZ - A Message from the Wizard

Upload index.html to GitHub Pages:
1. Create a new GitHub repository.
2. Upload index.html.
3. Settings -> Pages -> Deploy from branch -> main -> /root.
4. GitHub gives you a public website URL.
5. Put that URL into any QR generator and print the QR on the passport.

Suggested passport text:
🔮 SECRET SPELL
Scan to receive a message from Oz.
